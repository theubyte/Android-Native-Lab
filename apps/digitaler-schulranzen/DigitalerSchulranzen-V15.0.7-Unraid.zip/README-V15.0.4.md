# Digitaler Schulranzen V15.0.4

## Änderungen

- PDF/Buch: freies Zwei-Finger-Verschieben auch bei Fit-Zoom, gleichzeitiges Pinch-Zoom + Pan, keine automatische Zentrierung beim Verschieben, Zoom bis 10x Fit.
- Handschrift: automatische Formkorrektur ist deaktiviert. Handgezeichnete Dreiecke, Kreise und andere Formen bleiben exakt als Handschrift erhalten. Gerade Linien gibt es weiterhin über das explizite Lineal-Werkzeug.
- Rechnen durch Einkreisen: eine bewusst gezeichnete große geschlossene Kreis-/Oval-Geste wird als Rechen-Auswahl erkannt, ohne die Form zu verändern. Alle vorhandenen Stiftstriche innerhalb der Umrandung werden gemeinsam an die Handschrifterkennung übergeben und berechnet.
- Die Rechenblase zeigt bei eingekreisten Aufgaben den erkannten Ausdruck zusammen mit dem Ergebnis.
- Mathe-Normalisierung erweitert: Unicode-Multiplikation/Division/Gleichheitszeichen, Zeilenvarianten und vorsichtige Ziffern-Fallbacks.
- Beispieltest: `336*(55:15)` = `1232`.

Version: 15.0.4 / versionCode 1504
