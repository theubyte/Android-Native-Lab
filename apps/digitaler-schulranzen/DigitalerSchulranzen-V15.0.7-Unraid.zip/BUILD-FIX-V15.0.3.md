# V15.0.3

- Buch + Heft ist wieder direkt sichtbar in der Werkzeugleiste.
- Im Heft öffnet ⇄ die Buchauswahl; im bereits geteilten Modus schließt ⇄ die Teilung wieder.
- Im Buch öffnet ⇄ direkt die Heftauswahl.
- Landscape: nebeneinander. Portrait: untereinander.
- Der vorhandene verschiebbare Trenner bleibt erhalten.
