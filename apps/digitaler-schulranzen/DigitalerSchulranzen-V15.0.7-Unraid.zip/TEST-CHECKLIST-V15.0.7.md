# V15.0.7 Test

1. Auf kariertem Papier mehrere dicke und dünne Striche schreiben.
2. Teilradierer schnell in langen Bewegungen darüber ziehen; nach Loslassen dürfen keine kleinen Inseln wieder auftauchen.
3. Mehrfach hineinzoomen: bereits geschriebene Striche sollen deutlich glatter bleiben.
4. Während des Schreibens weiterhin auf geringe Latenz achten.
5. Undo/Redo nach Radieren prüfen.
