# V15 Geräte-Test – Tab S7 FE

1. APK über vorhandene V14/V13 installieren und prüfen, dass Daten erhalten bleiben.
2. Heft öffnen und 30–60 Sekunden schnell schreiben: keine sichtbaren Hänger beim Strich.
3. Langsam/kräftig und leicht schreiben: Linienbreite muss auf S-Pen-Druck reagieren.
4. S-Pen schweben: Werkzeugnamen müssen erscheinen; Handfläche darf nicht schreiben/scrollen.
5. Undo/Redo, Pen, Marker, Radierer, Farben und Dicke direkt über Dock testen.
6. Landscape: Dock links. Portrait: Dock oben. Rotation darf Inhalt nicht verlieren.
7. 2-Finger-Zoom, Seitenwechsel, Teil-/Strichradierer und 5-Finger-Übersicht testen.
8. PDF-Buch öffnen, annotieren, verlassen, neu öffnen: Annotationen müssen erhalten sein.
9. Vollbackup auf Unraid erstellen, App-Daten auf Testgerät zurücksetzen, Restore durchführen: PDFs/Bücher plus alle Annotationen müssen wieder vorhanden sein.
10. Hell/Dunkel umschalten und Bibliothek in beiden Modi prüfen.
