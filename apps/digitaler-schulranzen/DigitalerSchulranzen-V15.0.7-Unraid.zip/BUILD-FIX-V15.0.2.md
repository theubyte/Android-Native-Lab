# V15.0.2 Build Fix

- Behebt Java-Compilerfehler in `ThicknessSlider.setValueFromTool()`.
- `w` wird nun immer initialisiert, auch wenn beim Erzeugen des Sliders noch kein Notebook-/Book-View gebunden ist.
- Kotlin Duplicate-Class-Fix aus V15.0.1 bleibt erhalten.
- versionCode: 1502
- versionName: 15.0.2
