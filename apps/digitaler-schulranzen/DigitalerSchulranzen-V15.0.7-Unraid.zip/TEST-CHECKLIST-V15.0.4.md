# V15.0.4 Kurztest

1. Buch öffnen: mit zwei Fingern Seite ohne Zoom frei in alle Richtungen schieben. Pinch-Zoom und gleichzeitig verschieben testen. Nach Zoomen mit einem Finger schieben.
2. Im Heft Dreieck, Rechteck und Kreis langsam zeichnen: keine Form darf automatisch in einen Kreis umgewandelt werden.
3. `336*(55:15)` handschriftlich schreiben und danach mit einem großen handgezeichneten Kreis/Oval umschließen. Erwartet: Rechenblase zeigt Ausdruck und Ergebnis 1232.
4. Aufgabe einkreisen, die schon länger auf der Seite steht: sie muss ebenfalls erkannt werden; die Erkennung darf nicht nur die letzten Sekunden berücksichtigen.
5. Gerade Linie über das Lineal-Werkzeug weiterhin prüfen.
