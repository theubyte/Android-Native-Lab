# Digitaler Schulranzen V15

V15 ist ein UI- und Schreib-Performance-Update auf Basis von V14.

## Kernziel
Die Stifteingabe hat Vorrang vor Animation, Sync, OCR und sonstigen Nebenaufgaben. Die Schreibansicht verwendet Hardware-Layer, gecachtes Bestands-Ink, MotionEvent-Historie, Druck/Neigung und AndroidX Motion Prediction. Speichern wird verzögert und außerhalb des aktiven Schreibens ausgeführt.

## UI
- neue helle/dunkle Paper-/Soft-3D-Designsprache
- dezente Fachfarben als Kanten-/Glow-Akzent statt vollflächiger Karten
- adaptive Werkzeugleiste: links im Landscape, oben im Portrait
- Undo/Redo dauerhaft sichtbar
- Stift, Marker und Radierer dauerhaft sichtbar
- Farben und Stiftdicke direkt erreichbar, ohne Popup-Zwang
- Hover-Namen für S-Pen
- dezente Uhrzeit und Ambient-Animation auf der Bibliotheksseite
- sekundäre Werkzeuge in einer kurzen, animierten Zusatzleiste

## Schreiben
- hardwarebeschleunigte Schreibfläche
- gecachter Bestandstext/Bestands-Ink, nur aktiver Strich wird laufend neu gezeichnet
- MotionEvent-Historie + Motion Prediction
- einstellbare Druckkurve: aus / weich / natürlich / stark
- Stiftneigung optional
- asynchrones, entprelltes Speichern
- keine Save-Snapshot-Arbeit während eines neuen Stylus-Strichs
- echter Teilradierer und Strichradierer bleiben erhalten

## Backup
Vollbackup umfasst den app-eigenen Datenbestand inklusive lokalisierten/importierten PDF-Büchern, Heften, Arbeitsblättern, Markierungen, Notizen, Lesezeichen, Ausschnitten und Einstellungen. Restore prüft das Backup vor dem Ersetzen der lokalen Daten.

## Build
- applicationId: de.millione.schulranzen
- versionCode: 1500
- versionName: 15.0
- minSdk: 26
- targetSdk / compileSdk: 35
- Java 17

Der Unraid-Builder kann die ZIP direkt über `gradlew assembleDebug` bauen. Beim ersten V15-Build muss Gradle die AndroidX-Motion-Prediction-Abhängigkeit herunterladen können.
