# Test-Checkliste V15.0.6

1. Lange Heftseite mit vielen Strichen öffnen und Radierer 10-15 Sekunden schnell bewegen: keine deutlichen Ruckler.
2. Teilradierer prüfen: nur berührte Bereiche verschwinden.
3. Ganzstrich-Radierer prüfen: berührte Striche verschwinden vollständig.
4. S-Pen-Taste / Hardware-Radierer prüfen.
5. In einem Buch mehrere Markierungen/Striche anlegen und radieren: UI bleibt responsiv.
6. Bibliothek auf Galaxy Tab S7 FE prüfen: Titel, Tabs, Mappentexte und Uhrzeit wirken scharf und nicht bitmap-artig.
7. SHK Tools öffnen und Volumenstrom/Einheiten/Formeln testen.
8. Heft/Buch -> Mehr -> Prüfung: Seite bzw. Auswahl merken und wieder öffnen.
