# Digitaler Schulranzen V15.0.6

Schwerpunkt dieses Wartungsupdates: flüssigeres Radieren und schärfere UI-Schrift auf hochauflösenden Tablets.

## Neu / geändert
- Heft-Radierer: begrenztes, radiusabhängiges Resampling statt Verarbeitung aller historischen MotionEvents.
- Heft-Radierer: schnelle Bounding-Box-Vorprüfung vor teuren Stroke-Geometriechecks.
- Heft-Radierer: Ink-Bitmap wird während der Geste direkt gelöscht, statt nach jedem Radierpunkt vollständig neu aufgebaut zu werden.
- Buch-Radierer: Bewegungen werden gebündelt und geometrisch begrenzt; Stroke-Bounds beschleunigen die Trefferprüfung.
- TextViews: Subpixel-Text, Anti-Aliasing und Font-Hinting explizit aktiviert.
- Bibliotheksmappen: Canvas-Typografie nutzt Subpixel-Rendering und Hinting.
- Hardwarebeschleunigung explizit im Manifest aktiviert.
- Theme-Font auf Android `sans-serif` vereinheitlicht.
- VersionCode 1506 / VersionName 15.0.6.

Die V15.0.5-Funktionen bleiben enthalten: SHK-Schnellrechner, Einheiten-Assistent, Formelsammlung/Favoriten und Prüfungsmarkierungen.
