# Test-Checkliste V15.0.5

1. Startseite öffnen und `SHK Tools` starten.
2. Schnellrechner: 12 kW / ΔT 10 K → ca. 1,0318 m³/h bzw. 17,1969 l/min.
3. Schnellrechner: 17,2 l/min / ΔT 10 K → ca. 12,0022 kW.
4. Rohrinhalt: 16 mm / 100 m → ca. 20,1062 l.
5. Wasserenergie: 200 l / 45 K → ca. 10,467 kWh.
6. Einheiten: 1 bar → ca. 10,1972 mWS.
7. Einheiten: 2,5 m³/h → ca. 41,6667 l/min.
8. Einheiten: 20 °C → 293,15 K.
9. Formelsammlung: Stern setzen, Seite neu öffnen; Favorit bleibt gespeichert und steht oben.
10. Heft: Seite ohne Auswahl mit `✓ Prüfung` merken; in Prüfungsvorbereitung öffnen.
11. Heft: Lasso um Stiftstriche ziehen, `✓ Prüfung`; gespeicherter Ausschnitt fokussiert beim Wiederöffnen.
12. Buch: mit Ausschnitt-Werkzeug Bereich wählen, `✓ Prüfung`; gespeicherter Ausschnitt fokussiert beim Wiederöffnen.
13. Prüfungsmarkierung lang drücken und entfernen.
14. Server-Vollbackup erstellen; nach Restore bleiben SHK-Favoriten und Prüfungsmarkierungen erhalten.
15. Schreiben mit S Pen prüfen: SHK-Funktionen dürfen keine zusätzliche Latenz in NotebookView verursachen.
