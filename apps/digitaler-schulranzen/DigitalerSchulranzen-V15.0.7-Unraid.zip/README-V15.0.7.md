# Digitaler Schulranzen V15.0.7

- Radierer: kontinuierliche Kapsel-Geometrie statt Punkt-Sampling; keine Lücken zwischen Touch-Events.
- Radierer berücksichtigt Strichbreite und baut den Ink-Cache nach dem Radieren konsistent neu auf.
- Handschrift: 2x High-Resolution-Ink-Cache plus gefilterte Ausgabe beim Zoomen.
- Schreibdaten bleiben Vektor-/Punktdaten; nur die schnelle Bildschirm-Zwischendarstellung ist gerastert.
- versionCode 1507 / versionName 15.0.7.
