# V15.0.1 – Kotlin Duplicate-Class Fix

Der Unraid-Build von V15.0 ist bei `:app:checkDebugDuplicateClasses` fehlgeschlagen.
Ursache war eine gemischte Kotlin-Laufzeit:

- `kotlin-stdlib:1.8.10`
- `kotlin-stdlib-jdk7:1.7.20`
- `kotlin-stdlib-jdk8:1.6.0`

Seit Kotlin 1.8 sind die JDK7/JDK8-Erweiterungen in `kotlin-stdlib` enthalten. V15.0.1:

- nutzt die Kotlin BOM `1.8.10`,
- erzwingt eine einheitliche `kotlin-stdlib:1.8.10`,
- schließt die alten split JDK7/JDK8-Artefakte global aus.

App-Funktionen und Datenmodell bleiben unverändert.
