# Digitaler Schulranzen V15.0.5

## Neu: SHK-Werkzeugkasten
- Direkt auf der Startseite: `SHK Tools`.
- SHK-Schnellrechner mit sechs Berechnungen:
  - Volumenstrom aus Heizleistung und ΔT
  - Heizleistung aus Volumenstrom und ΔT
  - Rohrinhalt aus Innendurchmesser und Rohrlänge
  - Fließgeschwindigkeit aus Volumenstrom und Innendurchmesser
  - Energie zum Erwärmen einer Wassermenge
  - Druck ↔ Förderhöhe (bar / mWS)
- Live-Ergebnis direkt beim Eingeben.

## Einheiten-Assistent
Unterstützt Druck, Volumenstrom, Leistung, Energie, Länge, Volumen und Temperatur, u. a.:
- bar / mbar / kPa / Pa / mWS
- l/min / l/h / m³/h / m³/s
- W / kW
- Wh / kWh / MJ
- mm / cm / m
- ml / l / m³
- °C / K / °F

## Formelsammlung
- SHK-, Wärmelehre-, Rohrnetz- und Elektrotechnik-Grundformeln.
- Formeln mit Stern als Favorit speichern.
- Favoriten werden automatisch nach oben sortiert.
- Formeln mit passendem SHK-Rechner öffnen direkt die richtige Berechnung.

## Prüfungsmarkierungen
- In Heften und Büchern unter `Mehr Werkzeuge → ✓ Prüfung`.
- Ohne Auswahl wird die aktuelle Seite gemerkt.
- Mit Lasso-Auswahl im Heft oder Ausschnitt-Auswahl im Buch wird der konkrete Bereich gespeichert.
- Unter `Lernen → ✓` oder `SHK Tools → Prüfungsmarkierungen` gesammelt abrufbar.
- Beim Öffnen springt die App zur Quellseite und fokussiert gespeicherte Ausschnitte.
- Markierungen werden im bestehenden Vollbackup mitgesichert.

## Version
- versionCode: 1505
- versionName: 15.0.5
